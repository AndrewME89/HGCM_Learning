self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "59e3204b4d290ae9a4ea8d676b60bd03",
    "url": "@yield('content-viewer-url')/index.html"
  },
  {
    "revision": "8f85875416ebde3226aa",
    "url": "@yield('content-viewer-url')/static/css/2.37be29a2.chunk.css"
  },
  {
    "revision": "c74d4fe83fd74dd6d347",
    "url": "@yield('content-viewer-url')/static/css/main.1caf0e97.chunk.css"
  },
  {
    "revision": "8f85875416ebde3226aa",
    "url": "@yield('content-viewer-url')/static/js/2.979a5880.chunk.js"
  },
  {
    "revision": "cfb333affc1e9e4e40ea7a1e949500b6",
    "url": "@yield('content-viewer-url')/static/js/2.979a5880.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c74d4fe83fd74dd6d347",
    "url": "@yield('content-viewer-url')/static/js/main.97cf5e81.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "@yield('content-viewer-url')/static/js/main.97cf5e81.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b33a12fe361989d2d462",
    "url": "@yield('content-viewer-url')/static/js/runtime-main.eac69593.js"
  },
  {
    "revision": "a754c5ed00d8f6cca2a96794a2beaddc",
    "url": "@yield('content-viewer-url')/static/media/trophy.a754c5ed.svg"
  }
]);